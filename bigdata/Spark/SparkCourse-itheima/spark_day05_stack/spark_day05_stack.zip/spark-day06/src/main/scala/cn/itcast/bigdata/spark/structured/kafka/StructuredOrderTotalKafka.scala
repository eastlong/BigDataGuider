package cn.itcast.bigdata.spark.structured.kafka

import org.apache.spark.sql.streaming.{OutputMode, StreamingQuery, Trigger}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

/**
  * 结构化流式处理模块，从Kafka 读取数据（仅支持Kafka New Consumer API），直接获取Topic中的数据
  * 		实时统计各省份销售订单额
  */
object StructuredOrderTotalKafka {

	def main(args: Array[String]): Unit = {

		// TODO: 1、构建SparkSession实例对象，读取数据源的数据，封装在DataFrame/Dataset数据结构中
		val spark: SparkSession = SparkSession.builder()
			.master("local[3]")
			.appName("StructuredOrderTotalKafka")
			.config("spark.sql.shuffle.partitions", "3")
			.getOrCreate()
		spark.sparkContext.setLogLevel("WARN")

		// 隐式导入，主要用于RDD转换DataFrame
		import spark.implicits._
		// 导入SparkSQL中函数库
		import org.apache.spark.sql.functions._



		// TODO: 2、从Kafka Topic中实时获取数据
		val kafkaStreamDF: DataFrame = spark.readStream
	    	.format("kafka")
			.option("kafka.bootstrap.servers",
				"bigdata-cdh01.itcast.cn:9092,bigdata-cdh02.itcast.cn:9092,bigdata-cdh03.itcast.cn:9092")
			.option("subscribe", "orderTopic")
			.load()
		// kafkaStreamDF.printSchema()


		val provinceAmtStreamDF: DataFrame = kafkaStreamDF
			// 获取指定字段的值，转换数据类型（将binary转换为string）
	    	.selectExpr("CAST(value AS STRING)")
			// 指定数据类型，转换为Dataset
	    	.as[String]
			// 过滤不合格的数据
	    	.filter($"value".isNotNull and(length(trim($"value")) > 0))
			// 数据格式：orderId,provinceId,orderPrice
	    	.mapPartitions{ orders =>
				orders
			    	.filter(order => order.trim.split(",").length >= 3)
					.map{ order =>
						// 按照分隔符进行分割
						val Array(_, provinceId, orderAmt) = order.trim.split(",")
						// 返回二元组
						(provinceId.toInt, orderAmt.toDouble)
					}
			}
			// 对Dataset中列进行重命名
	    	.withColumnRenamed("_1", "provinceId").withColumnRenamed("_2", "orderAmt")
			// 按照省份ID进行累加订单金额
	    	.groupBy($"provinceId").agg(sum($"orderAmt").as("amtTotal"))


		// TODO: 将结果打印控制台
		val query: StreamingQuery = provinceAmtStreamDF.writeStream
			.outputMode(OutputMode.Update())
			.format("console")
			.start()

		query.awaitTermination()

	}

}
