package cn.itcast.bigdata.spark.structured.sink

import java.sql.{Connection, DriverManager, PreparedStatement}

import org.apache.spark.sql.streaming.{OutputMode, StreamingQuery}
import org.apache.spark.sql.{DataFrame, ForeachWriter, Row, SparkSession}

/**
  * 结构化流式处理模块，从Kafka 读取数据（仅支持Kafka New Consumer API），直接获取Topic中的数据
  * 		实时统计各省份销售订单额, 将结果输出到RDBMs表中
  */
object StructuredOrderTotalSink {

	def main(args: Array[String]): Unit = {

		// TODO: 1、构建SparkSession实例对象，读取数据源的数据，封装在DataFrame/Dataset数据结构中
		val spark: SparkSession = SparkSession.builder()
			.master("local[3]")
			.appName("StructuredOrderTotalSink")
			.config("spark.sql.shuffle.partitions", "3")
			.getOrCreate()
		spark.sparkContext.setLogLevel("WARN")

		// 隐式导入，主要用于RDD转换DataFrame
		import spark.implicits._
		// 导入SparkSQL中函数库
		import org.apache.spark.sql.functions._



		// TODO: 2、从Kafka Topic中实时获取数据
		val kafkaStreamDF: DataFrame = spark.readStream
	    	.format("kafka")
			.option("kafka.bootstrap.servers",
				"bigdata-cdh01.itcast.cn:9092,bigdata-cdh02.itcast.cn:9092,bigdata-cdh03.itcast.cn:9092")
			.option("subscribe", "orderTopic")
			.load()
		// kafkaStreamDF.printSchema()


		val provinceAmtStreamDF: DataFrame = kafkaStreamDF
			// 获取指定字段的值，转换数据类型（将binary转换为string）
	    	.selectExpr("CAST(value AS STRING)")
			// 指定数据类型，转换为Dataset
	    	.as[String]
			// 过滤不合格的数据
	    	.filter($"value".isNotNull and(length(trim($"value")) > 0))
			// 数据格式：orderId,provinceId,orderPrice
	    	.mapPartitions{ orders =>
				orders
			    	.filter(order => order.trim.split(",").length >= 3)
					.map{ order =>
						// 按照分隔符进行分割
						val Array(_, provinceId, orderAmt) = order.trim.split(",")
						// 返回二元组
						(provinceId.toInt, orderAmt.toDouble)
					}
			}
			// 对Dataset中列进行重命名
	    	.withColumnRenamed("_1", "provinceId").withColumnRenamed("_2", "orderAmt")
			// 按照省份ID进行累加订单金额
	    	.groupBy($"provinceId").agg(sum($"orderAmt").as("amtTotal"))


		// TODO: 将结果打印控制台
		val query: StreamingQuery = provinceAmtStreamDF.writeStream
			.outputMode(OutputMode.Update())
			// writer: ForeachWriter[T], 定义结果DataFrame输出
	    	.foreach(new ForeachWriter[Row]{
					// 声明连接
					var conn: Connection = _
					var pstmt: PreparedStatement = _

					// 打开连接
					override def open(partitionId: Long, version: Long): Boolean = {
						// a. 加载驱动类
						Class.forName("com.mysql.jdbc.Driver")

						// b. 获取连接
						conn = DriverManager.getConnection(
							"jdbc:mysql://bigdata-cdh01.itcast.cn:3306/test", "root", "123456"
						)

						// 编写SQL
						val sqlStr = "INSERT INTO result_province_amt(province_id, order_amt) VALUES (?, ?) ON DUPLICATE KEY UPDATE order_amt = VALUES(order_amt)"
						pstmt = conn.prepareCall(sqlStr)

						// 直接返回true，表示创建连接成功
						true
					}

					// 如何输出结果
					override def process(row: Row): Unit = {
						// 从Row中获取各个字段的值
						val provinceId = row.getInt(0)
						val amtTotal = row.getDouble(1)

						pstmt.setInt(1, provinceId)
						pstmt.setDouble(2, amtTotal)

						// 加入批次
						pstmt.addBatch()
					}

					// 关闭连接
					override def close(errorOrNull: Throwable): Unit = {
						// 批量插入
						pstmt.executeBatch()
						// 关闭连接
						if(null != pstmt) pstmt.close()
						if(null != conn) conn.close()
					}
			})
			.option("checkpointLocation", "datas/streaming/sql/order-10001")
			.start()


		provinceAmtStreamDF.writeStream
			.outputMode(OutputMode.Update())
	    	.format("console")
			.start()

		query.awaitTermination()

	}

}
