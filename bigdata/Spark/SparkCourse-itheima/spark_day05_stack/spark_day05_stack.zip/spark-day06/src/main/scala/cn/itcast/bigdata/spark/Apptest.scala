package cn.itcast.bigdata.spark

object Apptest {

	def main(args: Array[String]): Unit = {
		println("================ Hello Wolrd =====================")
	}

}
