package cn.itcast.bigdata.spark.kafka010

import java.text.SimpleDateFormat
import java.util.Date

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream, MapWithStateDStream}
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.{Seconds, State, StateSpec, StreamingContext}

/**
  * Streaming流式数据处理，从Kafka Topic读取数据，使用Kafka 0.10.0提供新的Consumer API读取数据，实时累加统计各个省份销售订单额
  */
object OrderTotalKafka010 {

	// 检查点目录
	val CHECKPOINT_PATH: String = "datas/streaming/state-order-011ddddd"

	/**
	  * 此函数表示从Kafka读取数据，实时统计各个省份销售订单额，最终将结果打印在控制台
	  * @param ssc
	  *            流式上下文实例对象
	  */
	def processStreaming(ssc: StreamingContext): Unit = {

		// TODO: 2、从Kafka Topic中读取数据，集成Kafka 0.10.0以上版本的新的消费者API
		/*
		  def createDirectStream[K, V](
			  ssc: StreamingContext,
			  locationStrategy: LocationStrategy,
			  consumerStrategy: ConsumerStrategy[K, V]
			): InputDStream[ConsumerRecord[K, V]]
		 */
		// 相当于：MapReduce处理数据是MapTask本地性，相对于RDD中分区数据处理的Perfered Location
		val locationStrategy: LocationStrategy = LocationStrategies.PreferConsistent
		/*
		  def Subscribe[K, V](
			  topics: Iterable[jl.String],
			  kafkaParams: collection.Map[String, Object]
		  ): ConsumerStrategy[K, V]
		 */
		// 表示从哪些Topic中读取数据
		val topics: Iterable[String] = Array("orderTopic")
		// 表示从Kafka 消费数据的配置参数，传递给KafkaConsumer
		val kafkaParams: collection.Map[String, Object] = Map(
			"bootstrap.servers" ->
				"bigdata-cdh01.itcast.cn:9092,bigdata-cdh02.itcast.cn:9092,bigdata-cdh03.itcast.cn:9092",
			"key.deserializer" -> classOf[StringDeserializer],
			"value.deserializer" -> classOf[StringDeserializer],
			"group.id" -> "kafka-order-group-0001",
			"auto.offset.reset" -> "latest",
			"enable.auto.commit" -> (false: java.lang.Boolean)
		)
		// 指定从Kafka消费数据的消费策略，涵盖topics和配置参数
		val  consumerStrategy: ConsumerStrategy[String, String] = ConsumerStrategies.Subscribe(
			topics, kafkaParams
		)
		// 从Kafka的Topic中读取数据
		val kafkaDStream: InputDStream[ConsumerRecord[String, String]] = KafkaUtils.createDirectStream[String, String](
			ssc, //
			locationStrategy, //
			consumerStrategy
		)

		// TODO: 3、实时统计各个省份销售订单额，数据格式：orderId,provinceId,orderPrice
		val ordersDStream: DStream[(Int, Double)] = kafkaDStream.transform{ rdd =>
			rdd
				// 过滤不合格的数据, 数据格式：orderId,provinceId,orderPrice
		    	.filter(record => null != record.value() && record.value().trim.split(",").length >= 3)
				// 获取topic中每条数据的value值
		    	.mapPartitions{ records =>
					records.map{ record =>
						// 按照分隔符进行分割
						val Array(_, provinceId, orderAmt) = record.value().trim.split(",")
						// 返回
						(provinceId.toInt, orderAmt.toDouble)
					}
				}
				// 对每批次数据进行聚合操作
		    	.reduceByKey(_ + _)
		}

		/**
		  * 使用新的状态更新函数，实时累加统计各个省份销售订单额
		  * 函数：mapWithState
		  * 	针对每批次中数据，一条一条的更新状态，有数据就更新，没有就不更新，也是依据Key更新状态
		  * 声明：
		  *	  def mapWithState[StateType: ClassTag, MappedType: ClassTag](
				  spec: StateSpec[K, V, StateType, MappedType]
				): MapWithStateDStream[K, V, StateType, MappedType]
		  	StateSpec：
		  		表示：封装如何一条一条数据进行更新状态
		    参数函数：
		  		- 第一个泛型参数：StateType
		  			状态的类型，针对应用就是省份总的销售订单额，Double
		  		- 第二个泛型参数：MappedType
		  			表示每条数据更新状态以后，返回给应用参数类型，针对此应用来说: 二元组 -> (省份ID， 省份总的销售订单额）
		  */
		/*
		  def function[KeyType, ValueType, StateType, MappedType](
		  	  // 此函数，才是真正对每批次中每条数据更新状态的
			  mappingFunction: (KeyType, Option[ValueType], State[StateType]) => MappedType
			): StateSpec[KeyType, ValueType, StateType, MappedType]
		 */
		val spec: StateSpec[Int, Double, Double, (Int, Double)] = StateSpec.function(
			// (KeyType, Option[ValueType], State[StateType]) => MappedType
			(provinceId: Int, orderAmt: Option[Double], state: State[Double]) => {
				// i. 获取当前批次中Key的状态（省份销售额
				val currentState = orderAmt.getOrElse(0.0)
				// ii. 获取Key的以前状态（省份的以前销售额）
				val previousState = state.getOption().getOrElse(0.0)
				// iii. 得到最新Key的转态
				val lastestState = currentState + previousState
				// iv. 更新当前Key状态信息
				state.update(lastestState)
				// v. 返回应用数据使用
				(provinceId, lastestState)
			}
		)
		// 使用状态更细函数，更新状态（销售额）
		val provincePriceDStream: MapWithStateDStream[Int, Double, Double, (Int, Double)] = ordersDStream.mapWithState(spec)


		// TODO: 4、将每批次统计分析的结果进行输出
		provincePriceDStream.foreachRDD{ (rdd, time) =>
			// TODO: 打印每批次时间，格式： 2019/07/10 11:39:00
			val batchTime = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date(time.milliseconds))
			println("-----------------------------------")
			println(s"batchTime: $batchTime")
			println("-----------------------------------")

			// 对于Streaming应用来说，输出RDD的时候，需要判断RDD是否存在
			if(!rdd.isEmpty()){
				// 针对RDD中每个分区数据操作
				rdd.foreachPartition{iter =>
					iter.foreach(println)
				}
			}
		}
	}

	def main(args: Array[String]): Unit = {

		// TODO: 1、构建Streaming应用上下文对象
		/*
		  def getOrCreate(
			  checkpointPath: String,
			  creatingFunc: () => StreamingContext,
			  hadoopConf: Configuration = SparkHadoopUtil.get.conf,
			  createOnError: Boolean = false
			): StreamingContext
		 */
		val context = StreamingContext.getOrCreate(
			// 当检查点目录存在的时候（非第一次运行），再次启动应用从此目录中的数据恢复StreamingContext
			CHECKPOINT_PATH, //
			// 当检查点目录不存在的时候，创建新的StreamingContxt实例对象，第一次运行的时候
			() => {
				val sparkConf = new SparkConf()
					.setMaster("local[3]") // 其中一个线程被运行Receiver接收器，剩余两个运行Task任务，并行的运行
					.setAppName("OrderTotalMapWithState")
					// TODO: 表示的是每秒钟读取每个分区的数据的条目数的最大值，此时3个分区，BatchInterval为5s，最大数据量：15万
					.set("spark.streaming.kafka.maxRatePerPartition", "10000")
				// def this(conf: SparkConf, batchDuration: Duration) 设置批处理时间间隔：划分流式数据时间间隔
				val ssc: StreamingContext = new StreamingContext(sparkConf, Seconds(5))

				// TODO：有状态的统计，使用以前批次Batch得到的状态，为了安全起见，程勋自动定时的将数据进行Checkpoint到文件系统
				ssc.checkpoint(CHECKPOINT_PATH)

				// 处理数据
				processStreaming(ssc)

				ssc
			}
		)

		// 设置级别
		context.sparkContext.setLogLevel("WARN")

		// TODO: 5、启动Streaming应用程序
		context.start() // 启动Receiver接收器，实时接收数据源的数据
		// 当流式应用启动以后，正常情况下，一直运行，除非程序异常或者人为停止
		context.awaitTermination()

		// 当应用运行完成以后，关闭资源
		context.stop(stopSparkContext = true, stopGracefully = true)
	}

}
