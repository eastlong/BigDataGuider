package cn.itcast.bigdata.spark.structured.sokcet

import org.apache.spark.sql.streaming.{OutputMode, ProcessingTime, StreamingQuery, Trigger}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

/**
  * Spark 2.x中结构化流式处理编程Structured Streaming
  * 	-a. 从TCP Socket读取数据
  * 	-b. 将数据封装在DataFrame中，调用函数处理分析
  * 	-c. 将分析结果打印在控制台中
  */
object StructuredWordCount {

	def main(args: Array[String]): Unit = {

		// TODO: 1、构建SparkSession实例对象，读取数据源的数据，封装在DataFrame/Dataset数据结构中
		val spark: SparkSession = SparkSession.builder()
	    	.master("local[3]")
	    	.appName("StructuredWordCount")
	    	.config("spark.sql.shuffle.partitions", "3")
	    	.getOrCreate()
		// 隐式导入，主要用于RDD转换DataFrame
		import spark.implicits._
		// 导入SparkSQL中函数库
		import org.apache.spark.sql.functions._

		spark.sparkContext.setLogLevel("WARN")


		// TODO: 2、从TCP Socket中实时读取数据
		val inputStreamDF: DataFrame = spark.readStream
	    	.format("socket")
			// 设置数据源相关属性
	    	.option("host", "bigdata-cdh03.itcast.cn")
	    	.option("port", "9999")
	    	.load()

		inputStreamDF.printSchema()


		// TODO: 3、对获取的数据封装在DataFrame中，词频统计WordCount
		val worcCountStreamDF: DataFrame = inputStreamDF
			// 指定数据类型，将DataFrame转换为Dataset
	    	.as[String]
			// 过滤不合格的数据
	    	.filter(line => null != line && line.trim.split("\\s+").length > 0)
			// 按照分隔符进行分割
	    	.flatMap(line => line.trim.split("\\s+").filter(word => word.length > 0))
			// 按照单词分组聚合统计
	    	.groupBy($"value").count()


		// TODO: 4、将分析的结果输出到控制台
		val query: StreamingQuery = worcCountStreamDF.writeStream
			// 输出模式，Complete表示将所有数据输出，相当于updateStateByKey函数，无论是否有更新，都输出所有
	    	//.outputMode(OutputMode.Complete())
			// 输出模式，Update表示有数据才更新
	    	.outputMode(OutputMode.Update())
			// TODO: 设置输出格式
	    	.format("console")
			// 设置输出格式参数值
	    	.option("numRows", "10")  // 输出数据的个数
	    	.option("truncate", "false") // 某列的字符长度大于20，是否截取输出
			// TODO: 设置触发时间间隔，相当于Streaming中BathcInterval，默认值为Trigger.ProcessingTime(0L)，有数据就处理
	    	.trigger(Trigger.ProcessingTime("5 seconds"))
			// 启动查询器Query（相当于启动Streaming流式程序）
	    	.start()

		// TODO: 5、等待流式应用停止
		query.awaitTermination()
	}

}
