package cn.itcast.bidata.spark

object AppTest {

	def main(args: Array[String]): Unit = {
		println("=========================")
	}

}
