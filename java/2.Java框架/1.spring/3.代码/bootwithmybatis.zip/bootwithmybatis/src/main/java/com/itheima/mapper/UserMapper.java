package com.itheima.mapper;

import com.itheima.domain.User;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * function:
 * Producered by xiaolong_wu on 2019/8/24
 **/

@Mapper
public interface UserMapper {
    List<User> queryUserList();
}
