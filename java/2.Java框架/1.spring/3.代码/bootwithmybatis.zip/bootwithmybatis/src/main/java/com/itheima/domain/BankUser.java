package com.itheima.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author xiaolong_wu
 * @date 2019年10月08日
 * @function
 **/
public class BankUser implements Serializable {
    private Integer id;
    private String bankUserName;
    private String birthday;
    private String sex;
    private String address;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return bankUserName;
    }

    public void setUsername(String username) {
        this.bankUserName = username;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "BankUser{" +
                "id=" + id +
                ", username='" + bankUserName + '\'' +
                ", birthday=" + birthday +
                ", sex='" + sex + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
