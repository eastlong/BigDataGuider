package com.itheima.mapper;

import com.itheima.domain.BankUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @author xiaolong_wu
 * @date 2019年10月08日
 * @function
 **/
@Mapper
public interface BankUserMapper {

    /** 查询所有操作 */
    List<BankUser> findAll();
    /** 保存用户 **/
    boolean saveBankUser(BankUser bankUser);

    /** 更新用户 **/
    boolean updateBankUser(BankUser bankUser);

    /** 根据id查询用户信息 */
    BankUser findById(int bankUserId);

     /** 根据名称模糊查询用户信息 like 注意在模糊查询时 传的符串前后需手动加入"%"*/
    List<BankUser> findByBankUserame(String bankUserName);

   /** 用聚合函数查询总人数 **/
    int findTotal();

    /** 根据id删除用户信息操作 */
    void deleteBankUser(int bankUserId);

}
