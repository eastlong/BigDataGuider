package com.itheima.service;

import com.itheima.domain.BankUser;
import com.itheima.factory.BeanFactory;
import com.itheima.mapper.BankUserMapper;
import com.itheima.utils.TransactionManager;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author xiaolong_wu
 * @date 2019年10月09日
 * @function
 **/
@Service
public class BankUserService implements BankUserMapper{

    @Autowired
    private BankUserMapper bankUserMapper;

    @Autowired
    private TransactionManager transactionManager;

    @Autowired
    private BeanFactory beanFactory;


    @Override
    public List<BankUser> findAll() {
        return bankUserMapper.findAll();
//        return beanFactory.getBankUserService().findAll();
    }

    @Override
    public boolean saveBankUser(BankUser bankUser) {
        return bankUserMapper.saveBankUser(bankUser);
    }

    @Override
    public boolean updateBankUser(BankUser bankUser) {
        return bankUserMapper.updateBankUser(bankUser);
    }

    @Override
    public BankUser findById(int bankUserId) {
        return bankUserMapper.findById(bankUserId);
    }

    @Override
    public List<BankUser> findByBankUserame(String bankUserName) {
        return bankUserMapper.findByBankUserame(bankUserName);
    }

    @Override
    public int findTotal() {
        return bankUserMapper.findTotal();
    }

    @Override
    public void deleteBankUser(int bankUserId) {
        bankUserMapper.deleteBankUser(bankUserId);
    }
}
