package com.itheima;

import com.itheima.domain.BankUser;
import com.itheima.mapper.BankUserMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author xiaolong_wu
 * @date 2019年10月08日
 * @function
 **/

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MyBankSpringBootApplication.class)

@ComponentScan(basePackages="com.itheima")
@EnableAspectJAutoProxy
public class MybatisTest {
    @Autowired
    private BankUserMapper bankUserMapper;


    @Test
    public void testFindAll()  {
        List<BankUser> bankUsers = bankUserMapper.findAll();
        System.out.println("### result:" + bankUsers.toString());
    }

    @Test
    public void testSaveBankUser(){
        BankUser bankUser = new BankUser();
        bankUser.setId(3);
        bankUser.setUsername("eee");
        bankUser.setAddress("天津");
        bankUser.setSex("girl");
        bankUser.setBirthday("1992-04-25");
        boolean bankUserSave = bankUserMapper.saveBankUser(bankUser);
        System.out.println("#### result:" + bankUserSave);
    }

    @Test
    public void testUpdateBankUser(){
        BankUser bankUser = new BankUser();
        bankUser.setId(6);
        bankUser.setUsername("fff");
        bankUser.setAddress("南昌");
        bankUser.setSex("boy");
        bankUser.setBirthday("1992-12-06");
        boolean updateBankUser = bankUserMapper.updateBankUser(bankUser);
        System.out.println("### result:" + updateBankUser);
    }

    @Test
    public void testFindById(){
        int id = 5;
        BankUser bankUser = bankUserMapper.findById(id);
        System.out.println("#### restlt:" + bankUser.toString());
    }

    @Test
    public void testFindByBankUserame(){
        String bankUserName = "aa";
        List<BankUser> bankUserList = bankUserMapper.findByBankUserame("%" + bankUserName + "%");
        System.out.println("#### result:" + bankUserList);
    }

    @Test
    public void testFindTotal(){
        int total = bankUserMapper.findTotal();
        System.out.println("#### result:" + total);
    }

    @Test
    public void testDeleteBankUser(){
        int id = 10;
        bankUserMapper.deleteBankUser(id);
    }

}
