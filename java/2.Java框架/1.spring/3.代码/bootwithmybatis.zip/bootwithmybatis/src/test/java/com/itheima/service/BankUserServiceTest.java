package com.itheima.service;

import com.itheima.MyBankSpringBootApplication;
import com.itheima.domain.BankUser;
import com.itheima.mapper.BankUserMapper;
import org.apache.ibatis.datasource.DataSourceFactory;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.Configuration;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.TransactionFactory;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.test.context.junit4.SpringRunner;

import javax.sql.DataSource;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * @author xiaolong_wu
 * @date 2019年10月09日
 * @function
 **/

@RunWith(SpringRunner.class)
@SpringBootTest(classes=MyBankSpringBootApplication.class)
@ComponentScan(basePackages="com.itheima")
@EnableAspectJAutoProxy
public class BankUserServiceTest {

    @Autowired
    private BankUserService bankUserService;


    @Test
    public void testFindAll() throws IOException {
        System.out.println("### result:" + bankUserService.findAll());
    }
}
