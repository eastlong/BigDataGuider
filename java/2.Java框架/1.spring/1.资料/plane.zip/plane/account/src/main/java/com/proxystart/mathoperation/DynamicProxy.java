package com.proxystart.mathoperation;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Random;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 动态代理，使用JDK内置的Proxy实现
 **/
public class DynamicProxy implements InvocationHandler {

    //被代理的对象
    Object targetObject;

    /**
     * @param object 被代理的对象
     * @return Object 代理后的对象
     */
    public Object getProxyObject(Object object){
        this.targetObject = object;
        return Proxy.newProxyInstance(
               targetObject.getClass().getClassLoader(),//类加载器
               targetObject.getClass().getInterfaces(),//获得被代理对象的所有接口
               this);//InvocationHandler对象
    }

    /**
     * @param proxy 被代理后的对象
     * @param method 将要被执行的方法信息（反射）
     * @param args 执行方法时需要的参数
     * @return
     * @throws Throwable
     */
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        //被织入的内容，开始时间
        long start = System.currentTimeMillis();
        lazy();

        //使用反射在目标对象上调用方法并传入参数
        Object result = method.invoke(targetObject,args);

        //被织入的内容，结束时间
        Long span = System.currentTimeMillis() - start;
        System.out.println("共用时：" + span);

        return result;
    }

    //模拟延时
    public void lazy()
    {
        try {
            int n = new Random().nextInt(500);
            Thread.sleep(n);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
