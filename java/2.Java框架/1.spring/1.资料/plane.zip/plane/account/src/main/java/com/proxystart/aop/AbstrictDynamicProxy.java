package com.proxystart.aop;

import org.springframework.aop.framework.ProxyFactory;

/**
 * @author xiaolong_wu
 * @date 2019年09月26日
 * @function 动态代理类封装
 **/
public abstract class AbstrictDynamicProxy {

    /** 获得代理对象
     * @param object 被代理的对象
     * @return Object 代理对象
     */
    public static Object getProxy(Object object){
        //获得代理对象
        ProxyFactory factory = new ProxyFactory();
        //设置被代理的对象
        factory.setTarget(object);
        //添加通知，横切逻辑
        factory.addAdvice(new TimeSpanAdvice());
        return factory.getProxy();
    }
}
