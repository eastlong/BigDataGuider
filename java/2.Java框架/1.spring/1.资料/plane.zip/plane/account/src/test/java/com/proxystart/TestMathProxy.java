package com.proxystart;

import com.proxystart.mathoperation.IMath;
import com.proxystart.mathoperation.MathProxy;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 静态代理测试类
 **/
public class TestMathProxy {

    IMath math = new MathProxy();
    int n1 = 100;
    int n2 = 5;

    @Test
    public void testAdd(){
        Assert.assertEquals(math.add(n1,n2),105);
    }

    @Test
    public void testSub(){
        math.sub(n1,n2);
        math.sub(n1, n2);
        math.mut(n1, n2);
        math.div(n1, n2);
        Assert.assertEquals(math.sub(n1,n2),95);
    }
}
