package com.itheima.dao.impl;

import com.itheima.dao.IAccountDao;
import com.itheima.domain.Account;
import com.itheima.service.impl.AccountServiceImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author xiaolong_wu
 * @date 2019年09月27日
 * @function
 **/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:bean.xml")
public class TestAccountDaoImpl {

    @Autowired
    private IAccountDao accountDao;


    @Test
    public void testFindAll(){
        System.out.println(accountDao.findAllAccount().toString());
    }

    @Test
    public void testFindAccountById(){
        System.out.println(accountDao.findAccountById(1));
    }

    @Test
    public void testSaveAccount(){
        Account account = new Account();
        account.setName("小吴");
        account.setMoney(1300f);
        accountDao.saveAccount(account);
    }

    @Test
    public void testUpdateAccount(){
        Account account = new Account();
        account.setId(13);
        account.setName("吴小龙");
        account.setMoney(13000f);
    }



}
