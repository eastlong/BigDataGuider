package com.proxystart;

import com.proxystart.mathoperation.DynamicProxy;
import com.proxystart.mathoperation.IMath;
import com.proxystart.mathoperation.Math;
import org.junit.Test;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 动态代理测试类
 **/
public class TestDynamicProxy {

    IMath math = (IMath) new DynamicProxy().getProxyObject(new Math());

    int n1 = 100;
    int n2 = 5;

    @Test
    public void testAdd(){
        math.add(n1,n2);
    }





}
