package com.proxystart.mathoperation;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 接口，抽象主题
 **/
public interface IMath {
    // 加
    int add(int n1,int n2);

    //减
    int sub(int n1,int n2);

    // 乘
    int mut(int n1,int n2);

    //除
    int div(int n1,int n2);
}
