package com.proxystart.actor;

/**
 * @author xiaolong_wu
 * @date 2019年09月27日
 * @function
 **/
public class Producer implements IProducer {

    @Override
    public void saleProduct(float money) {
        System.out.println("sale product,and get money:" + money);
    }

    @Override
    public void afterService(float money) {
        System.out.println("provide after service,and get money:" + money);
    }



}
