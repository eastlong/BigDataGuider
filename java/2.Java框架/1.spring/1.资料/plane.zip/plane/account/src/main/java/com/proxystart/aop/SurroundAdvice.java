package com.proxystart.aop;


import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 环绕通知;方法拦截器
 **/
public class SurroundAdvice implements MethodInterceptor {


    @Override
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {
        //前置横切逻辑
        System.out.println("method" + methodInvocation.getMethod() + "called in object"
            + methodInvocation.getThis() + ",Parameters" + methodInvocation.getArguments());
        //方法调用
        Object ret = methodInvocation.proceed();

        //后置横切逻辑
        System.out.println("返回值："+ ret);
        return ret;
    }
}
