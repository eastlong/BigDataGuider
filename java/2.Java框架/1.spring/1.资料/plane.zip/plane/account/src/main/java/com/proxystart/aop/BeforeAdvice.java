package com.proxystart.aop;

import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.lang.Nullable;

import java.lang.reflect.Method;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 前置通知
 **/
public class BeforeAdvice implements MethodBeforeAdvice {

    @Override
    public void before(Method method, Object[] objects, @Nullable Object o) throws Throwable {
        System.out.println("-----------------前置通知-----------------");

    }
}
