package com.accountaop;

import com.proxystart.accountaop.service.IAccountService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author xiaolong_wu
 * @date 2019年09月27日
 * @function
 **/
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:accountaopbean.xml")
public class AOPTest {

    @Test
    public void testAccountAop(){
        //1.获取容器
        ApplicationContext ac = new ClassPathXmlApplicationContext("accountaopbean.xml");
        //2.获取对象
        IAccountService as = (IAccountService)ac.getBean("accountService");
        //3.执行方法
        as.saveAccount();
        as.updateAccount(1);
        as.deleteAccount();

    }

}
