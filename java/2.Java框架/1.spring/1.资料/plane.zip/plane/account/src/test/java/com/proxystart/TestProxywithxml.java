package com.proxystart;

import com.proxystart.mathoperation.IMath;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author xiaolong_wu
 * @date 2019年09月26日
 * @function
 **/
public class TestProxywithxml {

    @Test
    public void testMath(){
        ApplicationContext ctx = new ClassPathXmlApplicationContext("bean.xml");
        //从代理工厂中获取代理对象
        IMath math = (IMath) ctx.getBean("proxy");
        int n1 = 100 , n2 = 5;
        math.add(n1,n2);
        math.sub(n1,n2);
        math.mut(n1,n2);
        math.div(n1,n2);
    }
}
