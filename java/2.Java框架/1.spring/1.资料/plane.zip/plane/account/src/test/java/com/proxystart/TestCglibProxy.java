package com.proxystart;

import com.proxystart.mathoperation.CglibProxy;
import com.proxystart.mathoperation.IMath;
import com.proxystart.mathoperation.Math;
import org.junit.Test;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function CGLib动态代理测试类
 **/
public class TestCglibProxy {
    IMath math = (IMath) new CglibProxy().getProxyObject(new Math());
    int n1 = 100;
    int n2 = 5;

    @Test
    public void testAdd(){
        math.add(n1,n2);
    }



}
