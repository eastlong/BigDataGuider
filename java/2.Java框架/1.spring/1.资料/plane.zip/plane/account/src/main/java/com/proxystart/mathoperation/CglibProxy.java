package com.proxystart.mathoperation;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;
import java.util.Random;

/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function
 **/
public class CglibProxy implements MethodInterceptor {
    //被代理的对象
    Object targetObject;

    public Object getProxyObject(Object object){
        this.targetObject = object;
        //增强器，动态代码生成器
        Enhancer enhancer = new Enhancer();
        //回调器
        enhancer.setCallback(this);
        //设置生成类的父类类型
        enhancer.setSuperclass(targetObject.getClass());
        //动态生成字节码并返回代理对象
        return enhancer.create();
    }

    /**
     * @param o
     * @param method
     * @param args
     * @param methodProxy
     * @return Object
     * @throws Throwable
     *  拦截方法
     */
    @Override
    public Object intercept(Object o, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {

        //被织入的横切内容，开始时间 before
        long start = System.currentTimeMillis();
        lazy();

        //调用方法
        Object result = methodProxy.invoke(targetObject,args);

        //被织入的横切内容，结束时间
        Long span = System.currentTimeMillis() - start;
        System.out.println("CglibProxy takes time:" + span);

        return result;
    }

    //模拟延时
    public void lazy()
    {
        try {
            int n = new Random().nextInt(500);
            Thread.sleep(n);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
