package com.proxystart.mathoperation;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;


/**
 * @author xiaolong_wu
 * @date 2019年09月25日
 * @function 被代理的目标对象 -- 真实主题
 **/
public class Math implements IMath{
    private static final Logger logger = LoggerFactory.getLogger(Math.class);

    @Override
    public int add(int n1, int n2) {
        int result = n1 + n2;
        System.out.println(n1+"+"+n2+"="+result);
        return result;
    }

    @Override
    public int sub(int n1, int n2) {
        int result=n1-n2;
        System.out.println(n1+"-"+n2+"="+result);
        return result;
    }

    @Override
    public int mut(int n1, int n2) {
        int result=n1*n2;
        System.out.println(n1+"X"+n2+"="+result);
        return result;
    }

    @Override
    public int div(int n1, int n2) {
        int result=n1/n2;
        System.out.println(n1+"/"+n2+"="+result);
        return result;
    }
}
