package com.proxystart.actor;


/**
 * 对生产厂家要求的接口
 */
public interface IProducer {

    void saleProduct(float money);

    void afterService(float money);

}
