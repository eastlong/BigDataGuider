package com.proxystart.aop;


import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import java.util.Random;

/**
 * @author xiaolong_wu
 * @date 2019年09月26日
 * @function 用于完成计算方法执行时长的环绕通知
 **/
public class TimeSpanAdvice implements MethodInterceptor {

    @Override
    public Object invoke(MethodInvocation methodInvocation) throws Throwable {
        //被织入的横切内容，开始时间before
        long start = System.currentTimeMillis();
        lazy();

        //方法调用
        Object result = methodInvocation.proceed();

        //被织入的横切内容，结束时间
        Long span = System.currentTimeMillis() - start;
        System.out.println("共用时：" + span);

        return result;
    }



    //模拟延时
    public void lazy()
    {
        try {
            int n = new Random().nextInt(500);
            Thread.sleep(n);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
