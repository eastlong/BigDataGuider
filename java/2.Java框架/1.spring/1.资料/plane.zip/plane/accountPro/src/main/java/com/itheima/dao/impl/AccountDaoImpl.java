package com.itheima.dao.impl;

import com.itheima.dao.IAccountDao;
import com.itheima.domain.Account;
import com.itheima.utils.ConnectionUtils;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.sql.SQLException;
import java.util.List;

/**
 * @author xiaolong_wu
 * @date 2019年09月24日
 * @function 账户的持久层实现类
 **/
@Repository("accountDao")
public class AccountDaoImpl implements IAccountDao {

    @Autowired
    private QueryRunner runner;

    @Autowired
    private ConnectionUtils connectionUtils;

    String findAllAccountSQL = "select * from account";
    String findAccountByIdSQL = "select * from account where id = ?";
    String saveAccountSQL = "insert into account(name,money)values(?,?)";
    String updataAccountSQL = "update account set name=?,money=? where id=?";
    String deleteAccountSQL = "delete from account where id = ?";
    String findAccountByName = "select * from account where name = ?";

    public void setRunner(QueryRunner runner) {
        this.runner = runner;
    }

    public void setConnectionUtils(ConnectionUtils connectionUtils) {
        this.connectionUtils = connectionUtils;
    }


    /**
     * 查询所有账户
     *
     * @return List<Account>
     */
    @Override
    public List<Account> findAllAccount() {
        try {
            return runner.query(connectionUtils.getThreadConnection(),
                    findAllAccountSQL, new BeanListHandler<Account>(Account.class));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    /**
     * 按Id查询账户
     *
     * @param accountId
     * @return Account
     */
    @Override
    public Account findAccountById(Integer accountId) {
        try {
            return runner.query(connectionUtils.getThreadConnection(),
                    findAccountByIdSQL, new BeanHandler<Account>(Account.class), accountId);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 保存账户
     *
     * @param account
     */
    @Override
    public void saveAccount(Account account) {
        try {
            runner.update(connectionUtils.getThreadConnection(),
                    saveAccountSQL,account.getName(),account.getMoney());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 更新账户
     *
     * @param account
     */
    @Override
    public void updateAccount(Account account) {
        try {
            //注意此处update带了参数
            runner.update(connectionUtils.getThreadConnection(),
                    "update account set name=?,money=? where id=?", account.getName(),account.getMoney(),account.getId());
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 删除账户
     *
     * @param accountId
     */
    @Override
    public void deleteAccount(Integer accountId) {
        try {
            runner.update(connectionUtils.getThreadConnection(),
                    deleteAccountSQL,accountId);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 根据名称查账户
     *
     * @param accountName
     * @return Account
     */
    @Override
    public Account findAccountByName(String accountName) {
        try {
            List<Account> accounts = runner.query(connectionUtils.getThreadConnection(),
                    findAccountByName, new BeanListHandler<Account>(Account.class), accountName);
            if (accounts == null || accounts.size() == 0) {
                return null;
            }
            if (accounts.size() > 1) {
                throw new RuntimeException("result set is not unique, The data have problems!");
            }
            return accounts.get(0);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
