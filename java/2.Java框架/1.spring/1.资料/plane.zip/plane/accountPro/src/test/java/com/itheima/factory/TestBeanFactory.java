package com.itheima.factory;

import com.itheima.config.SpringConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author xiaolong_wu
 * @date 2019年09月27日
 * @function
 **/

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath:bean.xml")
public class TestBeanFactory {

    @Autowired
    private BeanFactory beanFactory;

    @Test
    public void testGetAccountService(){
        System.out.println();
        beanFactory.getAccountService().transfer("aaa","bbb",5f);
    }
}
