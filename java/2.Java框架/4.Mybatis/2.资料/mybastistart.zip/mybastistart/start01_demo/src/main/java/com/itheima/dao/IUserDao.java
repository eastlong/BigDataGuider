package com.itheima.dao;

import com.itheima.domain.User;

import java.util.List;

public interface IUserDao {
    /**
     * 查询所有操作
     * @return
     */
    List<User> findAll();
    /**
     * 保存用户操作
     */
    boolean saveUser(User user);

    /**
     *  更新用户操作
     * @param user
     */
    boolean updateUser(User user);

    /**
     * 根据id删除用户信息操作
     * @param userId
     */
    boolean deleteUser(int userId);

    /**
     *  根据id查询用户信息
     */
    User findById(int userId);

    /**
     * 根据名称模糊查询用户信息 like
     * 注意在模糊查询时 传的 字符串前后 需手动加入"%"
     */
    List<User>findByUserame(String username);

    /**
     * 用聚合函数查询总人数
     **/
    int findTotal();
}
