package com.itheima;

import com.itheima.dao.IUserDao;
import com.itheima.domain.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * @author xiaolong_wu
 * @date 2019年09月12日
 * @function
 **/
public class MybatisTest {

    @Test
    public void testFindAll() throws IOException {

    //1.读取配置文件
    InputStream in = Resources.getResourceAsStream("SqlMapConfig.xml");
    //2.创建SqlSessionFactory工厂
    SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
    SqlSessionFactory factory = builder.build(in);
    //3.使用工厂生产SqlSession对象
    SqlSession session = factory.openSession();
    //4.使用SqlSession创建Dao接口的代理对象
    IUserDao userDao = session.getMapper(IUserDao.class);
    //5.使用代理对象执行方法
    List<User> users = userDao.findAll();
        for(User user : users){
        System.out.println(user);
    }
    //6.释放资源
        session.close();
        in.close();
    }

    @Test
//    测试保存操作
    public void testSaveUser() throws IOException {
        User user=new User();
        user.setUsername("鲁班七号");
        user.setSex("男");
        user.setBirthday(new Date());
        user.setAddress("召唤师峡谷");
        //读取配置文件,生成字节输出流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //获取SqlSession对象
        SqlSession session = factory.openSession();
        //获取dao的代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //保存User
        mapper.saveUser(user);

        //提交事务
        session.commit();
        //释放资源
        session.close();
        inputStream.close();
    }
    @Test
//    测试更新操作
    public void testUpdate() throws IOException {
        User user = new User();
        user.setId(6);
        user.setUsername("鲁班七号");
        user.setAddress("王者峡谷");
        user.setBirthday(new Date());
        user.setSex("男");


        //读取配置文件,生成字节输出流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //获取SqlSession对象
        SqlSession session = factory.openSession();
        //获取dao的代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //修改User
        mapper.updateUser(user);
        //提价事务
        session.commit();

        //释放资源
        session.close();
        inputStream.close();

    }
    @Test
    //测试删除User信息操作
    public void testDeleteUser() throws IOException {

        int userId = 9;

        //读取配置文件,获取字节输出资源流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //获取SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //获取SqlSession对象
        SqlSession session = factory.openSession();
        //获取dao代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //删除User
        mapper.deleteUser(userId);
        //提交事务
        session.commit();
        //关闭对象
        session.close();
        inputStream.close();
    }
    @Test
    //测试根据id查询User信息
    public void testFindById() throws IOException {
        int userId=3;
        //读取配置文件,获取字节输出资源流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //获取SqlSessionFactoryBuilder
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //获取SqlSession对象
        SqlSession session = factory.openSession();
        //获取dao代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //查询User信息
        User user = mapper.findById(userId);
        System.out.println();
        System.out.println(user);
        //释放资源
        session.close();
        inputStream.close();
    }
    @Test
    //根据Username查询User信息
    public void testFindByUsername() throws IOException {

        String username = "七";
        //读取配置文件,获取字节输出资源流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //创建SplSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //创建SqlSession对象
        SqlSession session = factory.openSession();
        //创建dao代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //查询User信息
        List<User> users = mapper.findByUserame("%"+username+"%");

        System.out.println();
        for (User user : users) {
            System.out.println(user);
        }
        //释放资源
        session.close();
        inputStream.close();
    }
    @Test
    //通过聚合函数查询总人数
    public void testFindTotal() throws IOException {
        //读取配置文件,获取字节输出资源流
        InputStream inputStream = Resources.getResourceAsStream("SqlMapConfig.xml");
        //创建SqlSessionFactory
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
        //创建SqlSession对象
        SqlSession session = factory.openSession();
        //创建dao代理对象
        IUserDao mapper = session.getMapper(IUserDao.class);
        //查询总人数
        int total = mapper.findTotal();
        System.out.println();
        System.out.println(total);
        //释放资源
        session.close();
        inputStream.close();

    }
}
