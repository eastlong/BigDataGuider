<template>
  <el-card>
    <el-table height="500px"
              :data="rightlist"
              border
              style="width: 100%">
      <el-table-column type=index
                       width="100"
                       label="序号">
      </el-table-column>
      <el-table-column prop="permissionName"
                       label="权限名称">
      </el-table-column>
      <el-table-column prop="permissionClass"
                       label="路径">
      </el-table-column>
      <el-table-column prop="poermissionLevel"
                       label="层级">
        <template slot-scope="scope">
          <span v-if="scope.row.poermissionLevel===0">一级</span>
          <span v-if="scope.row.poermissionLevel===1">二级</span>
          <span v-if="scope.row.poermissionLevel===2">三级</span>

        </template>
      </el-table-column>
    </el-table>
  </el-card>
</template>

<script>
export default {
  data () {
    return {
      rightlist: []
    }
  },
  created () {
    this.getRightList()
  },
  methods: {
    async getRightList () {
      const res = await this.axios.get(`permission/list`)
      console.log(res)
      this.rightlist = res.data.data
    }
  }
}
</script>

<style>
</style>
