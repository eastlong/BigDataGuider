<template>
  <el-card class="box-card">
    <!-- 1.搜索框 // 2020年03月22日 -- P153添加用户-->
    <el-row class="searchRow">
      <el-col>
        <el-input @clear="loadUserList"
                  placeholder="请输入内容"
                  clearable
                  v-model="query"
                  class="input-with-search">
          <el-button @click="searchUser"
                     slot="append"Y
                     icon="el-icon-search"></el-button>
        </el-input>
        <el-button type="success"
                   @click="showAddUser()">添加用户</el-button>
      </el-col>
    </el-row>

    <!-- 2.表格 -->
    <el-table :data="userlist"
              class="searchTable"
              style="width: 100%">
      <el-table-column type='index'
                       label="#"
                       width="60">
      </el-table-column>
      <el-table-column prop="mg_name"
                       label="姓名"
                       width="180">
      </el-table-column>
      <el-table-column prop="mg_email"
                       label="邮箱">
      </el-table-column>
      <el-table-column prop="mg_mobile"
                       label="电话">
      </el-table-column>
      <el-table-column prop="mg_time"
                       label="创建时间">
        <template slot-scope="userlist">
          {{  userlist.row.mg_time | fmtdate}}
        </template>
      </el-table-column>
      <el-table-column prop="mg_status"
                       label="用户状态">
        <template slot-scope="scope">
          <el-switch @change="changeMsgState(scope.row)"
                     v-model="scope.row.mg_state"
                     active-color="#13ce66"
                     inactive-color="#ff4949">
          </el-switch>
        </template>
      </el-table-column>
      <el-table-column prop="operation"
                       label="操作">
        <template slot-scope="scope">
          <el-row>
            <el-button size="small"
                       @click="showEditUserDia(scope.row)"
                       plain
                       type="primary"
                       icon="el-icon-edit"
                       circle></el-button>
            <el-button size="small"
                       @click="showDeleUserMsgBox(scope.row.mg_id)"
                       type="danger"
                       icon="el-icon-delete"
                       circle></el-button>
            <el-button size="small"
                       @click="showSetUserRoleDia(scope.row)"
                       type="success"
                       icon="el-icon-check"
                       circle>
            </el-button>
          </el-row>
        </template>
      </el-table-column>
    </el-table>

    <!-- 4. 分页 -->
    <el-pagination @size-change="handleSizeChange"
                   @current-change="handleCurrentChange"
                   :current-page="pagenum"
                   :page-sizes="[2, 4, 6, 8]"
                   :page-size="2"
                   layout="total, sizes, prev, pager, next, jumper"
                   :total='total'>
    </el-pagination>

    <!-- 对话框 -->
    <!-- 1. 添加用户对话框 -->
    <el-dialog title="添加用户"
               class="addUserDialog"
               :visible.sync="dialogFormVisibleAdd">
      <el-form :model="form">
        <el-form-item label="用户名"
                      label-width="100px">
          <el-input v-model="form.mg_name"
                    autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="密 码"
                      label-width="100px">
          <el-input v-model="form.mg_pwd"
                    autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮 箱"
                      label-width="100px">
          <el-input v-model="form.mg_email"
                    autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="电 话"
                      label-width="100px">
          <el-input v-model="form.mg_mobile"
                    autocomplete="off"></el-input>
        </el-form-item>

      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisibleAdd = false">取 消</el-button>
        <el-button type="primary"
                   @click="addUserSubmit()">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 2. 编辑用户对话框 -->
    <el-dialog title="编辑用户"
               class="addUserDialog"
               :visible.sync="dialogFormVisibleEdit">
      <el-form :model="form">
        <el-form-item label="用户名"
                      label-width="100px">
          <el-input v-model="form.mg_name"
                    disabled
                    autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="邮 箱"
                      label-width="100px">
          <el-input v-model="form.mg_email"
                    autocomplete="off"></el-input>
        </el-form-item>
        <el-form-item label="电 话"
                      label-width="100px">
          <el-input v-model="form.mg_mobile"
                    autocomplete="off"></el-input>
        </el-form-item>

      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisibleEdit = false">取 消</el-button>
        <el-button type="primary"
                   @click="editUserSubmit()">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 分配角色对话框 -->
    <el-dialog title="分配角色"
               :visible.sync="dialogFormVisibleRole">
      <el-form :model="form">
        <el-form-item label="用户名"
                      label-width="100px">
          <!-- {{currentUserName}} -->
        </el-form-item>
        <el-form-item label="角色"
                      label-width="100px">
          {{currRoleId}}

          <el-select v-model="currRoleId">
            <el-option label="请选择"
                       :value="-1"></el-option>
            <!-- :表示数字的-1 -->
            <el-option :label="item.role_name"
                       :value="item.role_id"
                       v-for="(item,i) in roles"
                       :key="i">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer"
           class="dialog-footer">
        <el-button @click="dialogFormVisibleRole = false">取 消</el-button>
        <el-button type="primary"
                   @click="setRole()">确 定</el-button>
      </div>
    </el-dialog>

  </el-card>
</template>

<script>
import { MessageBox } from 'element-ui'
export default {

  data () {
    return {
      query: '',
      pagenum: 1,
      pagesize: 2,
      userlist: [],
      total: -1,
      // 添加对话框的属性
      dialogFormVisibleAdd: false,
      dialogFormVisibleEdit: false,
      dialogFormVisibleRole: false,
      // 添加用户的表单数据
      form: {
        mg_name: '',
        mg_pwd: '',
        mg_email: '',
        mg_mobile: ''
      },
      currRoleId: -1,
      currUserId: -1,
      currentUserName: '',
      // 保存所有的角色
      roles: []
    }
  },
  created () {
    this.getUserList()
  },
  methods: {
    async setRole () {
      const res = await this.axios.put(`/updateRole/${this.currUserId}?role_id=${this.currRoleId}`)
      console.log(res)
      this.dialogFormVisibleRole = false
      if (res.status === 200) {
        this.$message.success('设置角色成功')
      }
    },
    async showSetUserRoleDia (user) {
      this.currentUserName = user.mg_name
      // 给currUserId赋值
      this.currUserId = user.mg_id
      // 获取所有角色
      const roleList = await this.axios.get(`/roleList`)
      console.log(roleList)
      this.roles = roleList.data.data

      // 获取当前用户的角色id --> rid
      const res = await this.axios.get(`/user/${user.mg_id}`)
      this.currRoleId = res.data.data.role_id
      console.log(res)
      this.dialogFormVisibleRole = true
    },
    async changeMsgState (user) {
      // 修改状态
      const res = await this.axios.put(`/updateState/${user.mg_id}?mg_state=${user.mg_state}`)
      console.log(res)
      if (res.status === 200) {
        this.$message.success('更新状态成功')
      }
    },
    // 编辑用户 - 提交
    async editUserSubmit () {
      const res = await this.axios.put(`/editUserManager/${this.form.mg_id}?mg_email=${this.form.mg_email}&mg_mobile=${this.form.mg_mobile}`)
      // 关闭对话框
      this.dialogFormVisibleEdit = false
      if (res.status === 200) {
        // 更新视图
        this.getUserList()
        // 提示成功
        this.$message.success('更新数据成功')
      } else {
        this.$message.warning('更新数据失败')
      }
      console.log(res)
    },
    // 编辑用户 - 显示对话框
    showEditUserDia (user) {
      this.form = {}
      console.log(user)
      // 获取用户数据
      this.form = user
      this.dialogFormVisibleEdit = true
    },
    // 删除用户 -> 打this开消息盒子
    showDeleUserMsgBox (userId) {
      MessageBox.confirm('刪除数据?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(async () => {
        // 发送删除请求
        const res = await this.axios.delete(`/deleteUserManager/${userId}`)
        console.log(res)
        if (res.status === 200) {
          // 提示
          this.$message.success('删除成功!')
          // 更新视图
          this.getUserList()
        }
      }).catch(() => {
        this.$message.info('已取消删除')
      })
    },

    // 添加用户提交-发送请求
    async addUserSubmit () {
      this.dialogFormVisibleAdd = false
      // const resTotal = await this.axios.post(`/addManagerUser`, this.form)
      // console.log(this.form)
      // console.log(resTotal)
      let postData = this.qs.stringify({
        mg_name: this.form.mg_name,
        mg_pwd: this.form.mg_pwd,
        mg_email: this.form.mg_email,
        mg_mobile: this.form.mg_mobile
      })
      const res = await this.axios({
        method: 'post',
        url: '/addManagerUser',
        data: postData
      })
      console.log('########')
      console.log(res)
      const msg = res.data.message
      if (res.status === 200) {
        // 更新视图
        this.getUserList()
        // 提示成功
        this.$message.success(msg)
        // 清空文本框
        this.form = {}
      } else {
        this.$message.warning('添加数据失败')
      }
    },
    // 添加用户 - 显示对话框
    showAddUser () {
      this.form = {}
      this.dialogFormVisibleAdd = true
    },
    loadUserList () {
      this.getUserList()
    },
    searchUser () {
      this.getUserList()
    },
    // 分页相关的方法
    handleSizeChange (val) {
      console.log(`每页 ${val} 条`)
      this.pagesize = val
      this.getUserList()
    },
    handleCurrentChange (val) {
      console.log(`当前页: ${val}`)
      this.pagenum = val
      this.getUserList()
    },
    // 获取用户列表的请求
    async getUserList () {
      const res = await this.axios.get(`/userManagerList?query=${this.query}&pageNum=${this.pagenum}&pageSize=${this.pagesize}`)
      console.log(res.data.data)
      const users = res.data.data
      console.log(users)
      const status = res.status
      console.log(status)
      const resTotal = await this.axios.get(`/total`)
      console.log(resTotal)
      // const msg = res.data.message
      if (status === 200) {
        // 1. 给表格数据赋值
        this.userlist = users
        // 2. 给total赋值
        this.total = resTotal.data
        // this.$message.success('请求成功')
        this.pagenum = 1
      }
    }
  }
}
</script>

<style>
.box-card {
  height: 100%;
}

.input-with-search {
  width: 300px;
}

.searchRow {
  margin-top: 5px;
}

.searchTable {
  margin-top: 20px;
}
</style>
