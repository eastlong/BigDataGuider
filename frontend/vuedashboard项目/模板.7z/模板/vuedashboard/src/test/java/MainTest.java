import com.betop.vuedashboard.VueDashboardApplication;
import com.betop.vuedashboard.controller.UserController;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @Author: eastlong
 * @Date 2020/3/22
 * @function:
 **/
@RunWith(value = SpringJUnit4ClassRunner.class)
@SpringBootTest(classes={VueDashboardApplication.class})
public class MainTest {
    @Autowired
    private UserController userController;

    @Test
    public void test(){
        System.out.println(userController.queryByPaging(3,2));
    }
}
