package com.betop.vuedashboard.controller;

import com.betop.vuedashboard.VueDashboardApplication;
import com.betop.vuedashboard.entity.AddBean;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @author: xiaolong_wu
 * Created at 2020/03/24
 * @function:
 **/
@RunWith(value = SpringJUnit4ClassRunner.class)
@SpringBootTest(classes={VueDashboardApplication.class})
public class UserManagerControllerTest {
    @Autowired
    private UserManagerController controller;

    @Test
    public void addTest(){
        AddBean addBean = new AddBean();
        addBean.setMg_pwd("51234");
        addBean.setMg_name("5spark");
        addBean.setMg_mobile("51234");
        addBean.setMg_email("5123@qq.com");

        System.out.println(controller.addManagerUser(addBean));
    }

    @Test
    public void testSearch(){
        String query = "";
        int pageNum = 2;
        int pageSize = 2;
        System.out.println("###:" +  controller.userManagerList(query,pageNum,pageSize).getData());
    }
}
