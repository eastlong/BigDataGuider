-- create database vuedashboard;

use vuedashboard;
-- 测试的user表
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `userId` int(20) NOT NULL AUTO_INCREMENT,
  `userDate` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userName` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userAddress` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`userId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 71 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (15, '2019-09-29T03:17:12.000Z', '王老三', '上海市普陀区金沙江路 1515 弄');
INSERT INTO `user` VALUES (16, '2019-09-29T03:27:05.000Z', '张小四', '上海市普陀区金沙江路 1514 弄');
INSERT INTO `user` VALUES (17, '2019-09-29T03:30:04.000Z', '王老五', '上海市普陀区金沙江路 1513弄');
INSERT INTO `user` VALUES (18, '2019-09-29T03:33:15.000Z', '小六子', '上海市普陀区金沙江路 1512弄');
INSERT INTO `user` VALUES (20, '2019-09-29T03:33:15.000Z', '王老八', '上海市普陀区金沙江路 1512弄');
INSERT INTO `user` VALUES (21, '2019-09-29T05:42:52.000Z', '王大拿', '上海市普陀区金沙江路 1511弄');
INSERT INTO `user` VALUES (22, '2019-09-29T05:43:50.000Z', '小九九', '上海市普陀区金沙江路 1510弄');
INSERT INTO `user` VALUES (23, '2019-09-29T05:43:50.000Z', '刘诗诗', '上海市普陀区金沙江路 1499弄');
INSERT INTO `user` VALUES (24, '2019-09-29T05:46:07.000Z', '扎昂四四', '上海市大湾区科技路');
INSERT INTO `user` VALUES (25, '2019-09-29T05:46:07.000Z', '扎昂四四新东方', '上海市大湾区科技路2001号');
INSERT INTO `user` VALUES (26, '2019-09-29T05:46:07.000Z', '王小虎', '上海市大湾区科技路2002号');
INSERT INTO `user` VALUES (27, '2019-09-29T05:46:07.000Z', '抽拉吧唧', '上海市大湾区科技路2003号');
INSERT INTO `user` VALUES (28, '2019-09-29T05:46:07.000Z', '年啦编辑', '上海市大湾区科技路2004号');
INSERT INTO `user` VALUES (29, '2019-09-29T05:46:07.000Z', '你多少', '上海市普陀区金沙江路 1211弄');
INSERT INTO `user` VALUES (30, '2019-09-29T05:46:07.000Z', '反发达', '上海市普陀区金沙江路 1212弄');
INSERT INTO `user` VALUES (31, '2019-09-29T05:51:20.000Z', '发官方', '上海市普陀区金沙江路 1213弄');
INSERT INTO `user` VALUES (32, '2019-09-29T05:51:20.000Z', '方还有', '上海市普陀区金沙江路 1214弄');
INSERT INTO `user` VALUES (33, '2019-09-29T05:51:20.000Z', '过不分', '上海市普陀区金沙江路 1498弄');
INSERT INTO `user` VALUES (34, '2019-09-29T05:51:20.000Z', '菜市场', '上海市普陀区金沙江路 1497弄');
INSERT INTO `user` VALUES (35, '2019-09-29T05:51:20.000Z', '权威的', '上海市普陀区金沙江路 1496弄');
INSERT INTO `user` VALUES (36, '2019-09-29T05:55:09.000Z', '冈反对的', '上海市大湾区科技路2001号');
INSERT INTO `user` VALUES (37, '2019-09-29T05:55:09.000Z', '冈反对', '上海市大湾区科技路2003号');
INSERT INTO `user` VALUES (38, '2019-09-29T05:55:09.000Z', '偶哦里面', '上海市大湾区科技路2004号');
INSERT INTO `user` VALUES (39, '2019-09-29T05:55:09.000Z', '偶哦韩大苏打', '上海市大湾区科技路2005号');
INSERT INTO `user` VALUES (40, '2019-09-29T05:55:09.000Z', '偶哦匀', '上海市大湾区科技路2006号');
INSERT INTO `user` VALUES (41, '2019-09-29T05:55:09.000Z', '敢哦匀', '上海市大湾区科技路2006号');
INSERT INTO `user` VALUES (42, '2019-09-29T05:55:09.000Z', '敢孩', '上海市大湾区科技路2006号');
INSERT INTO `user` VALUES (43, '2019-09-29T05:55:09.000Z', '敢女孩', '上海市大湾区科技路2007号');
INSERT INTO `user` VALUES (45, '2019-09-29T05:55:09.000Z', '工行行', '上海市大湾区科技路2008号');
INSERT INTO `user` VALUES (46, '2019-09-29T05:55:09.000Z', '家好吗', '上海市大湾区科技路2008号');
INSERT INTO `user` VALUES (47, '2019-09-29T05:55:09.000Z', '的程度', '上海市大湾区科技路2009号');
INSERT INTO `user` VALUES (48, '2019-09-29T05:55:09.000Z', '称得上', '上海市大湾区科技路2009号');
INSERT INTO `user` VALUES (49, '2019-09-29T05:55:09.000Z', '韩国和', '上海市大湾区科技路2010号');
INSERT INTO `user` VALUES (50, '2019-09-29T05:55:09.000Z', '韩好', '上海市大湾区科技路2010号');
INSERT INTO `user` VALUES (51, '2019-09-29T05:55:09.000Z', '韩吧', '上海市大湾区科技路2011号');
INSERT INTO `user` VALUES (52, '2019-09-29T05:55:09.000Z', '韩吧吧', '上海市大湾区科技路2012号');
INSERT INTO `user` VALUES (53, '2019-09-29T05:55:09.000Z', '长度是', '上海市大湾区科技路2013号');
INSERT INTO `user` VALUES (54, '2019-09-29T05:55:09.000Z', '比如合', '上海市大湾区科技路2014号');
INSERT INTO `user` VALUES (55, '2019-09-29T05:55:09.000Z', '如合境', '上海市大湾区科技路2015号');
INSERT INTO `user` VALUES (56, '2019-09-29T05:55:09.000Z', '如合国', '上海市大湾区科技路2016号');
INSERT INTO `user` VALUES (57, '2019-09-29T05:55:09.000Z', '如更好', '上海市大湾区科技路2017号');
INSERT INTO `user` VALUES (58, '2019-09-29T05:55:09.000Z', '如更法', '上海市大湾区科技路2018号');
INSERT INTO `user` VALUES (59, '2019-09-29T05:55:09.000Z', '反对', '上海市大湾区科技路2019号');
INSERT INTO `user` VALUES (60, '2019-09-29T05:55:09.000Z', '如国部', '上海市大湾区科技路2019号');
INSERT INTO `user` VALUES (61, '2019-09-29T06:04:15.000Z', '奇热网', '上海市普陀区金沙江路 1496弄');
INSERT INTO `user` VALUES (62, '2019-09-29T06:04:33.000Z', '反对法', '上海市普陀区金沙江路 1495弄');
INSERT INTO `user` VALUES (63, '2019-09-29T06:04:33.000Z', '的风格', '上海市普陀区金沙江路 1494弄');
INSERT INTO `user` VALUES (64, '2019-09-29T06:04:33.000Z', '广泛同', '上海市大湾区科技路2020号');
INSERT INTO `user` VALUES (65, '2019-09-10T06:04:33.000Z', '但仍然', '上海市普陀区金沙江路 1493弄');
INSERT INTO `user` VALUES (66, '2019-09-29T06:10:28.000Z', 'vdfv', '放到电饭锅的');
INSERT INTO `user` VALUES (67, '2019-09-14T16:00:00.000Z', '朱老六', '上海市高新区上海中心');
INSERT INTO `user` VALUES (69, '2019-09-10T16:00:00.000Z', '是的', ' 学生的三十四分');
INSERT INTO `user` VALUES (70, '2019-09-29T07:51:44.000Z', '张小子', '上海市浦东区1234号');

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------
-- Table structure for sp_permission
-- ----------------------------
DROP TABLE IF EXISTS `sp_permission`;
CREATE TABLE `sp_permission` (
  `ps_id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `ps_name` varchar(20) NOT NULL COMMENT '权限名称',
  `ps_pid` smallint(6) unsigned NOT NULL COMMENT '父id',
  `ps_c` varchar(32) NOT NULL DEFAULT '' COMMENT '控制器',
  `ps_a` varchar(32) NOT NULL DEFAULT '' COMMENT '操作方法',
  `ps_level` enum('0','2','1') NOT NULL DEFAULT '0' COMMENT '权限等级',
  PRIMARY KEY (`ps_id`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8 COMMENT='权限表';

-- ----------------------------
-- Records of sp_permission
-- ----------------------------
INSERT INTO `sp_permission` VALUES ('101', '商品管理', '0', '', '', '0');
INSERT INTO `sp_permission` VALUES ('102', '订单管理', '0', '', 'order', '0');
INSERT INTO `sp_permission` VALUES ('103', '权限管理', '0', '', '', '0');
INSERT INTO `sp_permission` VALUES ('104', '商品列表', '101', 'Goods', 'index', '1');
INSERT INTO `sp_permission` VALUES ('105', '添加商品', '104', 'Goods', 'tianjia', '2');
INSERT INTO `sp_permission` VALUES ('107', '订单列表', '102', 'Order', 'index', '1');
INSERT INTO `sp_permission` VALUES ('109', '添加订单', '107', 'Order', 'tianjia', '2');
INSERT INTO `sp_permission` VALUES ('110', '用户列表', '125', 'Manager', 'index', '1');
INSERT INTO `sp_permission` VALUES ('111', '角色列表', '103', 'Role', 'index', '1');
INSERT INTO `sp_permission` VALUES ('112', '权限列表', '103', 'Permission', 'index', '1');
INSERT INTO `sp_permission` VALUES ('115', '分类参数', '101', 'Type', 'index', '1');
INSERT INTO `sp_permission` VALUES ('116', '商品修改', '104', 'Goods', 'upd', '2');
INSERT INTO `sp_permission` VALUES ('117', '商品删除', '104', 'Goods', 'del', '2');
INSERT INTO `sp_permission` VALUES ('121', '商品分类', '101', '', '', '1');
INSERT INTO `sp_permission` VALUES ('122', '添加分类', '121', '', '', '2');
INSERT INTO `sp_permission` VALUES ('123', '删除分类', '121', '', '', '2');
INSERT INTO `sp_permission` VALUES ('125', '用户管理', '0', '', '', '0');
INSERT INTO `sp_permission` VALUES ('129', '添加角色', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('130', '删除角色', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('131', '添加用户', '110', '', '', '2');
INSERT INTO `sp_permission` VALUES ('132', '删除用户', '110', '', '', '2');
INSERT INTO `sp_permission` VALUES ('133', '更新用户', '110', '', '', '2');
INSERT INTO `sp_permission` VALUES ('134', '角色授权', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('135', '取消角色授权', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('136', '获取用户详情', '110', '', '', '2');
INSERT INTO `sp_permission` VALUES ('137', '分配用户角色', '110', '', '', '2');
INSERT INTO `sp_permission` VALUES ('138', '获取角色列表', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('139', '获取角色详情', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('140', '更新角色信息', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('141', '更新角色权限', '111', '', '', '2');
INSERT INTO `sp_permission` VALUES ('142', '获取参数列表', '115', '', '', '2');
INSERT INTO `sp_permission` VALUES ('143', '创建商品参数', '115', '', '', '2');
INSERT INTO `sp_permission` VALUES ('144', '删除商品参数', '115', '', '', '2');
INSERT INTO `sp_permission` VALUES ('145', '数据统计', '0', '', '', '0');
INSERT INTO `sp_permission` VALUES ('146', '数据报表', '145', '', '', '1');
INSERT INTO `sp_permission` VALUES ('147', '查看权限', '112', '', '', '2');
INSERT INTO `sp_permission` VALUES ('148', '查看数据', '146', '', '', '2');
INSERT INTO `sp_permission` VALUES ('149', '获取分类详情', '121', '', '', '2');
INSERT INTO `sp_permission` VALUES ('150', '更新商品图片', '104', '', '', '2');
INSERT INTO `sp_permission` VALUES ('151', '更新商品属性', '104', '', '', '2');
INSERT INTO `sp_permission` VALUES ('152', '更新商品状态', '104', '', '', '2');
INSERT INTO `sp_permission` VALUES ('153', '获取商品详情', '104', '', '', '2');
INSERT INTO `sp_permission` VALUES ('154', '订单更新', '107', '', '', '2');
INSERT INTO `sp_permission` VALUES ('155', '获取订单详情', '107', '', '', '2');
INSERT INTO `sp_permission` VALUES ('156', '分类参数添加', '101', '', '', '2');
INSERT INTO `sp_permission` VALUES ('157', '分类参数删除', '101', '', '', '2');
INSERT INTO `sp_permission` VALUES ('158', '分类参数详情', '101', '', '', '2');
INSERT INTO `sp_permission` VALUES ('159', '设置管理状态', '110', '', '', '2');



