package com.betop.vuedashboard.entity.resulttype;

/**
 * @author: xiaolong_wu
 * Created at 2020/03/28
 * @function:
 **/
public class PageInfo {
    private String query;
    private Integer pageNum;
    private Integer getPagSize;

    public PageInfo() {
    }

    public PageInfo(String query, Integer pageNum, Integer getPagSize) {
        this.query = query;
        this.pageNum = pageNum;
        this.getPagSize = getPagSize;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getGetPagSize() {
        return getPagSize;
    }

    public void setGetPagSize(Integer getPagSize) {
        this.getPagSize = getPagSize;
    }
}
