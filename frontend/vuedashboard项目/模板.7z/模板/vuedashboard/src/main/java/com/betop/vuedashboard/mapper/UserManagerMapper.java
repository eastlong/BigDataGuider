package com.betop.vuedashboard.mapper;

import com.betop.vuedashboard.entity.UserManager;
import com.betop.vuedashboard.entity.resulttype.Role;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface UserManagerMapper {

    int total(); // 一共多少条数据

    UserManager searchById(@Param("mg_id") Integer mg_id);

    List<UserManager> userManagerList(
            @Param("query") String query,
            @Param("pageNum") int pageNum,
            @Param("pageSize") int pageSize);

    boolean addManagerUser(
            @Param("mg_name") String mg_name,
            @Param("mg_pwd") String mg_pwd,
            @Param("mg_email") String mg_email,
            @Param("mg_mobile") String mg_mobile
    );
    /**
     * @param userId
     * @return boolean
     * 删除用户
     */
    boolean deleteUserManager(@Param("mg_id") Integer userId);

    /**
     * @param userId
     * @param email
     * @param mobile
     * @return boolean
     * 编辑用户
     */
    boolean editUserManager(@Param("mg_id") Integer userId,
                            @Param("mg_email") String email,
                            @Param("mg_mobile") String mobile);


    /**
     * @param userId
     * @param mg_state
     * @return boolean
     * 更新状态
     */
    boolean updateState(@Param("mg_id") Integer userId,@Param("mg_state") Integer mg_state);

    List<Role> roleList();

    /**
     * 根据id查找role信息
     * @param
     * @return
     */
    // Role searchRoleById(Integer mg_id);

    /**
     *
     * @param mg_id
     * @param role_id
     * @return boolean
     * 设置角色
     */
    boolean updateRole(@Param("mg_id") Integer mg_id,@Param("role_id") Integer role_id);

}
