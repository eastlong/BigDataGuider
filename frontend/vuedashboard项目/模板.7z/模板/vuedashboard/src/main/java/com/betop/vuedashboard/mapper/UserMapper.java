package com.betop.vuedashboard.mapper;

import com.betop.vuedashboard.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @function: UserMapper
 * @author: xiaolong_wu
 * Created at 2020/03/06
 **/
@Mapper
public interface UserMapper {
    public List<User> findUserByName(String userName);

    public List<User> ListUser();

    public List<User> queryPage(Integer startRows);

    public int getRowCount();

    public int insertUser(User user);

    public int delete(int userId);

    public int Update(User user);

    public List<User> queryByPaging(@Param("pageNum") Integer pageNum,@Param("pageSize") Integer pageSize);
}
