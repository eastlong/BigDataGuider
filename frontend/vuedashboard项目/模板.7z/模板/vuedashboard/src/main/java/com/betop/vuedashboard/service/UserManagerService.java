package com.betop.vuedashboard.service;

import com.betop.vuedashboard.entity.AddBean;
import com.betop.vuedashboard.entity.UserManager;
import com.betop.vuedashboard.entity.resulttype.Role;
import com.betop.vuedashboard.mapper.UserManagerMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author: eastlong
 * @Date 2020/3/22
 * @function:
 **/
@Service
public class UserManagerService {
    @Autowired
    private UserManagerMapper userManagerMapper;

    /**
     * @param pageNum
     * @param pageSize
     * @return List<UserManager>
     * 分页查询
     */
    public List<UserManager> userManagerList(String query,int pageNum, int pageSize) {
        return userManagerMapper.userManagerList(query,(pageNum - 1) * pageSize, pageSize);
    }

    /**
     * @param mg_id
     * @return UserManager
     * 根据id查询
     */
    public UserManager searchById(Integer mg_id) {
        return userManagerMapper.searchById(mg_id);
    }

    public int total(){
        return userManagerMapper.total();
    }

    /**
     * @return 新增用户
     */
    public boolean addManagerUser(String mg_name,
                                  String mg_pwd,
                                  String mg_email,
                                  String mg_mobile){
        return userManagerMapper.addManagerUser(mg_name,mg_pwd,mg_email,mg_mobile);
    }

    public boolean deleteUserManager(Integer mg_id){
        return userManagerMapper.deleteUserManager(mg_id);
    }

    /**
     * @param mg_id
     * @param mg_email
     * @param mg_mobile
     * @return boolean
     * 修改用户
     */
    public boolean editUserManager(Integer mg_id,String mg_email,String mg_mobile){
        return userManagerMapper.editUserManager(mg_id,mg_email,mg_mobile);
    }

    /**
     * 更新状态
     * @param userId
     * @param state
     * @return boolean
     */
    public boolean updateState(Integer userId,Integer state){
        return userManagerMapper.updateState(userId,state);
    }

    /**
     * @return List<String>
     * 查询角色
     */
    public List<Role> roleList(){
        return userManagerMapper.roleList();
    }

    /**
     * @param mg_id
     * @return Role
     * 查询角色明细信息
     */
    /**
    public Role searchRoleById(Integer mg_id){
        return userManagerMapper.searchRoleById(mg_id);
    }
     */

    public boolean updateRole(Integer mg_id,Integer role_id){
        return userManagerMapper.updateRole(mg_id,role_id);
    }
}
