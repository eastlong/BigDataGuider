package com.betop.vuedashboard.controller;

import com.betop.vuedashboard.common.Result;
import com.betop.vuedashboard.common.StatusCode;
import com.betop.vuedashboard.entity.Permission;
import com.betop.vuedashboard.service.PermissionManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @author: xiaolong_wu
 * Created at 2020/04/06
 * @function:
 **/
@RequestMapping(value="/permission")
@Controller
public class PermissionManagerController {
    @Autowired
    private PermissionManagerService service;

    @RequestMapping(value="/list")
    @ResponseBody
    public Result getPermissionList(){
        List<Permission> permissionList = service.getPermissionList();
        return new Result(true, StatusCode.OK,"请求成功",permissionList);
    }

    @RequestMapping(value="/hello")
    @ResponseBody
    public String hello(){
        return "Hello,World!";
    }
}
