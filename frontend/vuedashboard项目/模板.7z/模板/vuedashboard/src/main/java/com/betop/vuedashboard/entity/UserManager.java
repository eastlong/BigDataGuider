package com.betop.vuedashboard.entity;

/**
 * @Author: eastlong
 * @Date 2020/3/22
 * @function:
 **/
public class UserManager {
    private int mg_id;
    private String mg_name;
    private String mg_pwd;
    private Long mg_time;
    private int role_id;
    private String mg_mobile;
    private String mg_email;
    private boolean mg_state;

    public UserManager() {
    }

    public UserManager(int mg_id, String mg_name,
                       String mg_pwd, Long mg_time,
                       int role_id, String mg_mobile,
                       String mg_email, boolean mg_state) {
        this.mg_id = mg_id;
        this.mg_name = mg_name;
        this.mg_pwd = mg_pwd;
        this.mg_time = mg_time;
        this.role_id = role_id;
        this.mg_mobile = mg_mobile;
        this.mg_email = mg_email;
        this.mg_state = mg_state;
    }

    public int getMg_id() {
        return mg_id;
    }

    public void setMg_id(int mg_id) {
        this.mg_id = mg_id;
    }

    public String getMg_name() {
        return mg_name;
    }

    public void setMg_name(String mg_name) {
        this.mg_name = mg_name;
    }

    public String getMg_pwd() {
        return mg_pwd;
    }

    public void setMg_pwd(String mg_pwd) {
        this.mg_pwd = mg_pwd;
    }

    public Long getMg_time() {
        return mg_time;
    }

    public void setMg_time(Long mg_time) {
        this.mg_time = mg_time;
    }

    public int getRole_id() {
        return role_id;
    }

    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }

    public String getMg_mobile() {
        return mg_mobile;
    }

    public void setMg_mobile(String mg_mobile) {
        this.mg_mobile = mg_mobile;
    }

    public String getMg_email() {
        return mg_email;
    }

    public void setMg_email(String mg_email) {
        this.mg_email = mg_email;
    }

    public boolean isMg_state() {
        return mg_state;
    }

    public void setMg_state(boolean mg_state) {
        this.mg_state = mg_state;
    }

    @Override
    public String toString() {
        return "UserManager{" +
                "mg_id=" + mg_id +
                ", mg_name='" + mg_name + '\'' +
                ", mg_pwd='" + mg_pwd + '\'' +
                ", mg_time=" + mg_time +
                ", role_id=" + role_id +
                ", mg_mobile='" + mg_mobile + '\'' +
                ", mg_email='" + mg_email + '\'' +
                ", mg_state=" + mg_state +
                '}';
    }
}
