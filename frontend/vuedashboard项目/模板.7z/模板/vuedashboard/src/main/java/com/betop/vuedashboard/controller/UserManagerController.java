package com.betop.vuedashboard.controller;

import com.betop.vuedashboard.common.Result;
import com.betop.vuedashboard.common.StatusCode;
import com.betop.vuedashboard.entity.AddBean;
import com.betop.vuedashboard.entity.UserManager;
import com.betop.vuedashboard.entity.resulttype.Role;
import com.betop.vuedashboard.service.UserManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: eastlong
 * @Date 2020/3/22
 * @function:
 **/
@RestController
@CrossOrigin
public class UserManagerController {
    @Autowired
    private UserManagerService userManagerService;

    @RequestMapping(value="/userManagerList")
    @ResponseBody
    public Result userManagerList(String query, int pageNum, int pageSize){
        List<UserManager> userManagerList = userManagerService.userManagerList(query,pageNum,pageSize);
        return new Result(true, StatusCode.OK,"请求成功",userManagerList);
    }

    @RequestMapping(value="/user/{mg_id}")
    @ResponseBody
    public Result searchById(@PathVariable Integer mg_id){
        UserManager userManager = userManagerService.searchById(mg_id);
        return new Result(true,StatusCode.OK,"请求成功",userManager);
    }

    @RequestMapping(value="/total")
    @ResponseBody
    public int total(){
        return userManagerService.total();
    }

    /**
     * @return 新增用户
     */
    @RequestMapping(value="/addManagerUser", method = RequestMethod.POST)
    @ResponseBody
    public Result addManagerUser(AddBean addBean){
        String mg_name = addBean.getMg_name();
        String mg_pwd = addBean.getMg_email();
        String mg_email = addBean.getMg_email();
        String mg_mobile = addBean.getMg_mobile();
        boolean result = userManagerService.addManagerUser(mg_name,mg_pwd,mg_email,mg_mobile);
        return new Result(result,StatusCode.OK,"用户创建成功",addBean);
    }

    @DeleteMapping(value="/deleteUserManager/{userId}")
    public Result deleteUserManager(@PathVariable Integer userId){
        boolean result = userManagerService.deleteUserManager(userId);
        return new Result(result,StatusCode.OK,"删除成功");
    }

    @RequestMapping(value="/editUserManager/{userId}",method = RequestMethod.PUT)
    public Result editUserManager(@PathVariable Integer userId,
                                  String mg_email,
                                  String mg_mobile){
        boolean resulet = userManagerService.editUserManager(userId,mg_email,mg_mobile);
        return new Result(resulet,StatusCode.OK,"修改成功");
    }

    @RequestMapping(value="/updateState/{mg_id}",method = RequestMethod.PUT)
    public Result updateState(@PathVariable Integer mg_id,Boolean mg_state){
        int state = 0;
        if(mg_state){
            state = 1;
        }
        boolean result = userManagerService.updateState(mg_id,state);
        return new Result(result,StatusCode.OK,"状态更新成功");
    }

    /**
     * @return Result
     * 角色列表
     */
    @RequestMapping(value="/roleList")
    @ResponseBody
    public Result roleList(){
        List<Role> roles = new ArrayList<>();
        roles = userManagerService.roleList();
        return new Result(true,StatusCode.OK,"请求成功",roles);
    }

    /**
    @RequestMapping(value="/role")
    @ResponseBody
    public Result searchRoleById(@PathVariable Integer mg_id){
        Role role = userManagerService.searchRoleById(mg_id);
        return new Result(true,StatusCode.OK,"查询用户角色成功",role);
    }
    */

    /**
     *
     * @param mg_id
     * @param role_id
     * @return
     * 更新角色
     */
    @RequestMapping(value="/updateRole/{mg_id}",method = RequestMethod.PUT)
    @ResponseBody
    public Result updateRole(@PathVariable Integer mg_id,Integer role_id){
        boolean res = userManagerService.updateRole(mg_id,role_id);
        UserManager userManager = userManagerService.searchById(mg_id);
        return new Result(res,StatusCode.OK,"更新角色成功",userManager);
    }
}
