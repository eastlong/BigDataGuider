package com.betop.vuedashboard.entity;

/**
 * @author: xiaolong_wu
 * Created at 2020/04/06
 * @function:
 **/
public class Permission {
    private Integer permissionId;
    private String permissionName;
    private Integer permissionPid;
    private String permissionClass;
    private String permissionAction;
    private Integer poermissionLevel;

    public Permission() {
    }

    public Permission(Integer permissionId, String permissionName,
                      Integer permissionPid, String permissionClass,
                      String permissionAction, Integer poermissionLevel) {
        this.permissionId = permissionId;
        this.permissionName = permissionName;
        this.permissionPid = permissionPid;
        this.permissionClass = permissionClass;
        this.permissionAction = permissionAction;
        this.poermissionLevel = poermissionLevel;
    }

    public Integer getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(Integer permissionId) {
        this.permissionId = permissionId;
    }

    public String getPermissionName() {
        return permissionName;
    }

    public void setPermissionName(String permissionName) {
        this.permissionName = permissionName;
    }

    public Integer getPermissionPid() {
        return permissionPid;
    }

    public void setPermissionPid(Integer permissionPid) {
        this.permissionPid = permissionPid;
    }

    public String getPermissionClass() {
        return permissionClass;
    }

    public void setPermissionClass(String permissionClass) {
        this.permissionClass = permissionClass;
    }

    public String getPermissionAction() {
        return permissionAction;
    }

    public void setPermissionAction(String permissionAction) {
        this.permissionAction = permissionAction;
    }

    public Integer getPoermissionLevel() {
        return poermissionLevel;
    }

    public void setPoermissionLevel(Integer poermissionLevel) {
        this.poermissionLevel = poermissionLevel;
    }

    @Override
    public String toString() {
        return "Permission{" +
                "permissionId=" + permissionId +
                ", permissionName='" + permissionName + '\'' +
                ", permissionPid=" + permissionPid +
                ", permissionClass='" + permissionClass + '\'' +
                ", permissionAction='" + permissionAction + '\'' +
                ", poermissionLevel=" + poermissionLevel +
                '}';
    }
}
