package com.betop.vuedashboard.entity;

import org.apache.ibatis.annotations.Param;

/**
 * @author: xiaolong_wu
 * Created at 2020/03/24
 * @function:
 **/
public class AddBean {

    private String mg_name;
    private String mg_pwd;
    private String mg_email;
    private String mg_mobile;

    public AddBean() {
    }

    public AddBean(String mg_name, String mg_pwd,
                   String mg_email, String mg_mobile) {
        this.mg_name = mg_name;
        this.mg_pwd = mg_pwd;
        this.mg_email = mg_email;
        this.mg_mobile = mg_mobile;
    }

    public String getMg_name() {
        return mg_name;
    }

    public void setMg_name(String mg_name) {
        this.mg_name = mg_name;
    }

    public String getMg_pwd() {
        return mg_pwd;
    }

    public void setMg_pwd(String mg_pwd) {
        this.mg_pwd = mg_pwd;
    }

    public String getMg_email() {
        return mg_email;
    }

    public void setMg_email(String mg_email) {
        this.mg_email = mg_email;
    }

    public String getMg_mobile() {
        return mg_mobile;
    }

    public void setMg_mobile(String mg_mobile) {
        this.mg_mobile = mg_mobile;
    }

    @Override
    public String toString() {
        return "AddBean{" +
                "mg_name='" + mg_name + '\'' +
                ", mg_pwd='" + mg_pwd + '\'' +
                ", mg_email='" + mg_email + '\'' +
                ", mg_mobile='" + mg_mobile + '\'' +
                '}';
    }
}
