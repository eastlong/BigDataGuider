package com.betop.vuedashboard.service;

import com.betop.vuedashboard.entity.Permission;
import com.betop.vuedashboard.mapper.PermissionManagerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author: xiaolong_wu
 * Created at 2020/04/06
 * @function:
 **/
@Service
public class PermissionManagerService {
    @Autowired
    private PermissionManagerMapper permissionManagerMapper;

    public List<Permission> getPermissionList(){
        return permissionManagerMapper.getRightList();
    }
}
