package com.betop.vuedashboard.mapper;

import com.betop.vuedashboard.entity.Permission;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author: xiaolong_wu
 * Created at 2020/04/06
 * @function: 权限管理接口类
 **/
@Mapper
public interface PermissionManagerMapper {
    /**
     * 获取权限列表
     * @return List<Permission>
     */
    List<Permission> getRightList();

}
